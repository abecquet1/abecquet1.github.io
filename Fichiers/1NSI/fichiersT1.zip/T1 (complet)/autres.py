"""
dans ce fichier, on donne quelques focntions générales sur les dictionnaires
"""


def injectif(d):
    """teste si le dictionnaire d est invectif, cad que deux clés n'ont jamais la même valeur"""
    return len(set(d.values())) == len(list(d.values()))


def inv(d):
    """renvoie le dictionnaire inverse de d (les clé deviennes valeur et vice-versa)"""
    if not(injectif(d)):
        print("Attention ! Dictionnaire non-injectif")
    d2 = {}
    for k in d:
        d2[d[k]] = k
    return d2








