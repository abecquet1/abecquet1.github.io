from exercices import plus_frequent
from pgr1920 import occurrence

"""
Dans ce programme, on utilise les fonctions occurrences et plus_frequent pour faire l'analyse
de l'utilisation des mots de la déclarations des droits de l'homme de 1789
"""


#on récupère les lignes du fichier ddh.txt
f = open("ddh.txt", 'r')
t = f.readlines()
f.close()

#on nettoie les texte des caractères de ponctuations 
for i in range(len(t)):
    t[i] = t[i].replace(',', '')
    t[i] = t[i].replace('.', '')
    t[i] = t[i].replace(':', '')
    t[i] = t[i].replace(';', '')
    t[i] = t[i].replace("l'", '')
    t[i] = t[i].replace("d'", '')
    t[i] = t[i].replace('"', '')
    t[i] = t[i].replace('\n', '')
    t[i] = t[i].lower()

#on construit un tableau contenant l'ensembles des mots du texte
mots = []
for ligne in t:
    for mot in ligne.split(' '):
        mots.append(mot)

#d est le dictionnaires d'occurrence des mots du texte
d = occurrence(mots)

print("Analyse du texte de la déclaration des droits de l'hommes de 1789 :")
for i in range(1,17):
    print("    Mot de", i, "lettres le plus fréquent :", plus_frequent(d, i))










