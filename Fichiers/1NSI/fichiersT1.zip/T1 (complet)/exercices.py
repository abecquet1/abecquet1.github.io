from random import *
from math import *





#ex 174
def paradoxe(k, n=1000):
    """renvoie le nombre de groupe avec au moins
    deux anniversaires communs dans n groupes de
    k personnes prises au hasard"""
    nb_paradoxe = 0
    for i in range(n):
        groupe = [randint(1,365) for j in range(k)]
        if doublon(groupe):
            nb_paradoxe+=1
    return nb_paradoxe/n



#ON NE FAIT PAS LE 175




#ex 176
def plus_frequent(d,k):
    """renvoie la clé de taille k de plus grande valeur associée dans le dictionnaire d"""
    #on commence par extraire la liste des mots de taille k
    mots_de_taille_k = []
    for mot in d.keys():
        if len(mot) == k:
            mots_de_taille_k.append(mot)
            
    if mots_de_taille_k == []:
        #si la liste est vide, on doit renvoyer ""
        return ""
    else:
        #sinon on recherche le mot de taille k ayant la plus grande valeur dans le dictionnaire
        mot_max = mots_de_taille_k[0]
        for m in mots_de_taille_k:
            if d[m]>d[mot_max]:
                mot_max = m
        return mot_max




#ex 177
def compare_tableaux(t1,t2):
    """teste si les tableaux t1 et t2 ont exactement les mêmes valeurs"""
    return occurrence(t1) == occurrence(t2)


#ex 178
"""
cela renvoie
{'t':1, 'a':3, 'g':1, 'd':1}
"""


#ex179
def inverse_clavier(clav):
    """renvoie le dictionnaire des coordonnées des touches du clavier passé en argument"""
    d = {}
    for i in range(len(clav)):
        for j in range(len(clav[i])):
            d[clav[i][j]] = (i,j)
    return d

#clavier azerty pour les tests
azerty = []
azerty.append(['1','2','3','4','5','6','7','8','9','0'])
azerty.append(['a','z','e','r','t','y','u','i','o','p'])
azerty.append(['q','s','d','f','g','h','j','k','l','m'])
azerty.append(['<','w','x','c','v','b','n',',',';',':'])
azerty.append([' '])

def distance_touche(clav, c1, c2):
    """renvoie la distance entre les touches c1 et c2 sur le clavier clav"""
    d = inverse_clavier(clav)
    i1, j1 = d[c1]
    i2, j2 = d[c2]
    return sqrt((i2-i1)**2+(j2-j1)**2)




















    
        
    


