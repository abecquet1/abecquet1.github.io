def doublon(t):
    """programme 19 : teste si le tableau t comporte des doublons"""
    deja_vu = set()
    for x in t:
        if x in deja_vu:
            return True
        else:
            deja_vu.add(x)
    return False

def occurrence(t):
    """programme 20 : renvoie le dictionnaire des occurrences de t"""
    occ = {}
    for x in t:
        if not(x in occ.keys()):
            occ[x]=1
        else:
            occ[x]+=1
    return occ

