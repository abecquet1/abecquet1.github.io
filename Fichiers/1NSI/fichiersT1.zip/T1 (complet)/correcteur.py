from exercices import distance_touche, azerty
import unicodedata

"""
Dans ce programme, on utilise la fonction de distance entre les touches d'un clavier pour proposer
un correcteur orthographique basique
"""

#liste des caractères courants à ne pas prendre en compte
interdit = [',',';',':',':', '!',"l'","d'",'?','.','/', "§", '(', ')','-', '\n']

#on importe la listes des mots du dictionnaire français qu'on nettoie en retirant les caractère interdit et accentués
f = open('liste_francais.txt', 'r')
fr = f.readlines()
f.close()
for i in range(len(fr)):
    for c in interdit:
        fr[i] = fr[i].replace(c, '')    #caractères interdits
    fr[i] = fr[i].lower()               #minuscules
    fr[i] = unicodedata.normalize('NFKD', fr[i]).encode('ascii', 'ignore').decode() #accents



    
def distance(m1, m2, clav):
    """renvoie la somme des distances entre les caractères des deux mots selon le clavier"""
    if len(m1)!=len(m2):
        return 99999999
    d = 0
    for i in range(len(m1)):
        d += distance_touche(clav, m1[i], m2[i])
    return d


def mot_le_plus_proche(mot, clav = azerty, dico = fr):
    """renvoie le mot du dictionnaire le plus proche au sens de la fonction distance du mot argument"""
    mot_min = dico[0]
    d_min = distance(clav, mot, mot_min)
    for m in dico:
        d = distance(mot, m, clav)
        if d < d_min:
            d_min = d
            mot_min = m
    return mot_min


print("Correcteur orthographique : ")
print("    Entrer un mot non-accetué, enminuscule et sans caractère spécial.")
print("    Pour arrêter, entrer '!stop'.")
acq = "GO"
while acq!="!stop":
    acq = input()
    if acq != "!stop":
        print(mot_le_plus_proche(acq, clav = azerty, dico = fr))
    
        
            



    
        
    



