from turtle import *

n = int(input("Nombres de marches :"))
for i in range(n):
    forward(25)
    left(90)
    forward(25)
    right(90)
