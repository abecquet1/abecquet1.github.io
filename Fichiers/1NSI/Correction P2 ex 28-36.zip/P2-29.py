from turtle import *

### flocon ###
for i in range(6):
    forward(200)
    backward(200)
    left(60)

#je vais au bon endroit
up()
forward(200)
left (120)
down()

### hexagone ###
for i in range(6):
    forward(200)
    left (60)
    
