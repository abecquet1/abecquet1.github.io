class Graphe:
    """un graphe comme un dictionnaire d'adjacence"""

    def __init__(self):
        self.adj = {}

    def ajouter_sommet(self, s):
        if s not in self.adj:
            self.adj[s] = set()

    def ajouter_arc(self, s1, s2):
        self.ajouter_sommet(s1)
        self.ajouter_sommet(s2)
        self.adj[s1].add(s2)

    def arc(self, s1, s2):
        return s2 in self.adj[s1]

    def sommets(self):
        return list(self.adj)

    def voisins(self, s):
        return self.adj[s]

    def afficher(self):
        for s in self.adj:
            print(s, self.adj[s])

    def nb_sommets(self):
        return len(self.adj)

    def degre(self,s):
        return len(self.adj[s])

    def nb_arcs(self):
        return sum(self.degre(s) for s in self.sommets())


