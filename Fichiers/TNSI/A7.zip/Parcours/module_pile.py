class Cellule : 
    def __init__(self, v, s):
        self.valeur = v
        self.suivante = s

class Pile :
    def __init__(self):
        self.contenu = None
        self._taille = 0
    
    def est_vide(self): 
        return self.contenu is None
    
    def empiler(self, e):
        self.contenu = Cellule(e, self.contenu)
        self._taille +=1

    def depiler(self):
        if self.est_vide():
            raise IndexError("Pile vide !")
        res = self.contenu.valeur
        self.contenu = self.contenu.suivante
        self._taille -=1
        return res

    def consulter(self):
        x = self.depiler()
        self.empiler(x)
        return x

    def vider(self):
        self.contenu = None
        elf._taille = 0

    def __len__(self):
        return self._taille



