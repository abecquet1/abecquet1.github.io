from module_pile import *
from module_file import *
from module_graphe import *



# PARCOURS EN PROFONDEUR RECURSIF (programme 39)

def parcours_profondeur_rec(g, vus, s):
    """parcours en profondeur g à partir de s, modifie vue par effet de bord"""
    if s not in vus:
        #print(s)
        vus.add(s)
        for v in g.voisins(s):
            parcours_profondeur_rec(g, vus, v)




# EXISTENCE D'UN CHEMIN ENTRE DEUX SOMMETS (programme 39)

def existe_chemin(g, u, v):
    vus = set()
    parcours_profondeur(g, vus, u)
    return v in vus




# PARCOURS EN PROFONDEUR AVEC PILE (programme 40)

def parcours_profondeur_pile(g, s, vus):
    """parcours en profondeur g à partir de s, modifie vue par effet de bord"""
    pile = Pile()
    pile.empiler(s)
    while not pile.est_vide():
        s = pile.depiler()
        if s not in vus:
            #print(s)
            vus.add(s)
            for v in g.voisins(s):
                pile.empiler(v)




# DETECTION DE CYCLE (programme 41)

BLANC, GRIS, NOIR = 0, 1, 2

def parcours_cycle(g, couleur, s):
    """parcours g en profondeur à partir de s jusqu'à détecter un cycle"""
    # s peut être blanc, gris ou noir
    
    if couleur[s] == BLANC:                     # blanc = on rencontre s pour la première fois
        couleur[s] = GRIS                       # il pourait y avoir un cycle
        for v in g.voisins(s):      
            if parcours_cycle(g, couleur, v):   # on lance un parcours sur ses voisins
                return True                     # par s on peut aller à un sommet déjà vu 
        couleur[s] = NOIR                     
        return False                            # par s on ne peut aller à aucun sommet déjà vu
    
    elif couleur[s] == GRIS:  # gris = on a déjà rencontré s dans le parcours -> cycle détecté 
        return True
    
    elif couleur == NOIR:     # noir = on sait qu'un parcours en profondeur à partir de s ne donne lieu à auccun cycle 
        return False
    

def cycle(g):
    """teste si g présente un cycle"""
    couleur = {}
    for s in g.sommets():
        couleur[s] = BLANC                  # tous les sommets commencent blanc
    for s in g.sommets():                   # on tente un parcours depuis chaque sommet (les sommets marqués NOIRS ne sont pas retestés)
        if parcours_cycle(g, couleur, s):
            return True
    return False                            # si aucun parcours ne présente un cycle, g n'en présente pas 






# PARCOURS EN LARGEUR AVEC ENSEMBLES COURANTS/SUIVANTS (programme 42)

def parcours_largeur_ensemble(g, s):
    """parcours en largeur g à partir de s, renvoie le disctionnaire des distances à s"""
    dist = {s:0}    # les sommets déjà traités, et leur distance à s
    courant = {s}   # les sommets à une distance d de s
    suivant = set() # les sommets à une distance d+1 de s
    while len(courant)>0:
        s = courant.pop()
        #print(s)
        for v in g.voisins(s):
            if v not in dist:
                suivant.add(v)
                dist[v] = dist[s]+1
        if len(courant) == 0:
            courant, suivant = suivant, set()
    return dist




# CALCUL DE DISTANCE (programme 42)

def distance(g, s1, s2):
    """renvoie la distance entre s1 et s2 dans le graphe g (None si pas de chemin)"""
    dist = parcours_largeur_ensemble(g, s1)
    if s2 in dist:
        return dist[s2]
    return None





# BONUS : PARCOURS EN LARGEUR AVEC FILE
           
def parcours_largeur_file(g, s):
    """parcours en largeur g à partir de s, renvoie le disctionnaire des distances à s"""
    dist = {s:0}    # les sommets déjà traités, et leur distance à s
    file = File()   # les sommets à traiter, par distance croissante à s 
    file.ajouter(s)
    while not file.est_vide():
        s = file.retirer()
        #print(s)
        for v in g.voisins(s):
            if v not in dist:
                dist[v] = dist[s]+1
                file.ajouter(v)
    return dist






#### TEST ###


g = Graphe()
g.ajouter_arc(0,1)
g.ajouter_arc(1,0)
g.ajouter_arc(0,2)
g.ajouter_arc(2,0)
g.ajouter_arc(1,2)
g.ajouter_arc(2,1)
g.ajouter_arc(1,3)
g.ajouter_arc(3,4)
g.ajouter_arc(4,2)
g.ajouter_arc(3,1)
g.ajouter_arc(4,3)
g.ajouter_arc(2,4)






