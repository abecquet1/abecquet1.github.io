class Cellule : 
    def __init__(self, v, s):
        self.valeur = v
        self.suivante = s

class Pile :
    def __init__(self):
        self.contenu = None
    
def est_vide(p): 
    return p.contenu is None
    
def creer_pile():
    return Pile()
    
def empiler(p, e):
    p.contenu = Cellule(e, p.contenu)

def depiler(p):
    if est_vide(p):
        raise IndexError("Pile vide !")
    res = p.contenu.valeur
    p.contenu = p.contenu.suivante
    return res


"""
### TESTS ###
p = creer_pile()
for i in range(10):
    empiler(p,i)
for i in range(10):
    print(depiler(p))
print(est_vide(p))
"""
