class Cellule:
    def __init__(self, v, s):
        self.valeur = v
        self.suivante = s

class File:
    def __init__(self):
        self.tete = None
        self.queue = None
        
def creer_file():
    return File()

def est_vide(f): 
    return f.tete is None
    
def ajouter(f, e):
    #on cree la cellule devant etre mise en fin de liste
    c = Cellule(e, None)
    if est_vide(f):
        #dans ce cas, la cellule ajoutee est en tete
        f.tete = c 
    else :
        #un lien de l'ancienne vers la nouvelle queue
        f.queue.suivante = c
    #quoiqu'il arrive la cellule ajoutee est en queue
    f.queue = c
        
def retirer(p):
    if f.tete is None :
        raise IndexError("File Vide !")
    #on va renvoyer la valeur de la tete
    res = f.tete.valeur
    #on met a jour la tete
    f.tete = f.tete.suivante
    if p.tete is None:
        #si cela vide la file, la queue est egalement vide
        f.queue = None
    return res


"""
### TESTS ###
f = creer_file()
for i in range(10):
    ajouter(f,i)
for i in range(10):
    print(retirer(f))
print(est_vide(f))
"""
