class Pile :
    def __init__(self):
        self.contenu = []
    
def est_vide(p): 
    return p.contenu == []
    
def creer_pile():
    return Pile()
    
def empiler(p, e):
    p.contenu.append(e)

def depiler(p):
    if est_vide(p):
        raise IndexError("Pile vide !")
    return p.contenu.pop()


"""
### TESTS ###
p = creer_pile()
for i in range(10):
    empiler(p,i)
for i in range(10):
    print(depiler(p))
print(est_vide(p))
"""
