### Execrice 1 ###

def eratosthene(n):
    t = [i for i in range(2,n+1)]
    for i in range(n-1) :
        p = t[i]
        if p!=0:
            for j in range(i+1,n-1):
                if t[j]%p==0:
                    t[j]=0
    return t

def eratosthene_bis(n):
    t = [i for i in range(2,n+1)]
    for i in range(2, n+1) :
        if t[i-2]!=0:
            k = 2
            while k*i-2<n-1:
                t[k*i-2]=0
                k=k+1    
    return t


### Exercice 2 ###

def u(n):
    if n==0:
        return 5
    else:
        return 4*u(n-1)-1

def occurrences(t,i,x):
    if i>=len(t):
        return 0
    else:
        if t[i]==x:
            return 1+occurrences(t,i+1,x)
        else:
            return occurrences(t,i+1,x)


### Exercice 3 ###

###### Supposés disponible :
class Cellule:
    def __init__(self,v,s):
        self.valeur = v
        self.suivante = s

class Pile:
    def __init__(self):
        self.contenu = None

def creer():
    return Pile()

def ajouter(p, x):
    p.contenu = Cellule(x, p.contenu)

def est_vide(p):
    return p.contenu is None

def retirer(p):
    if est_vide(p):
        raise IndexError
    else :
        res = p.contenu.valeur
        p.contenu = p.contenu.suivante
        return res

###### Parenthèses :
def bien_parenthesee(s):
    p = creer()
    for c in s :
        if c == '(' or c == '[':
            #pas de probleme pour les ouvrantes
            ajouter(p, c)
        elif c == ']':
            if est_vide(p):
                #on n a rien ouvert avant -> mal parenthesee
                return False
            else :
                c1 = retirer(p)
                if c1!='[':
                    #la derniere ouverte est du mauvais type -> mal parenthesee
                    return False
        elif c == ')':
            if est_vide(p):
                #on n a rien ouvert avant -> mal parenthesee
                return False
            else :
                c1 = retirer(p)
                if c1!='(':
                    #la derniere ouverte est du mauvais type -> mal parenthesee
                    return False
    #tout va bien, sauf s il reste des parentheses ouvrantes non fermees, la pile doit donc etre vide
    return est_vide(p)
