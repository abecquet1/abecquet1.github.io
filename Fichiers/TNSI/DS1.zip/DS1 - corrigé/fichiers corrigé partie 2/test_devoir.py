from random import randint
from date_devoir import *

dates = []
for m in range(1,13):
    nb_j = 31
    if m == 2 :
        nb_j = 29
    elif m in [4,6,9,11]:
        nb_j = 30     
    for j in range(1,nb_j+1):
        dates.append(Date(j,m,2020))


for d in dates:
    print(d)

for _ in range(20):
    i = randint(0,365)
    j = randint(0,365)
    print("Comparaison", str(dates[i]),"<", str(dates[j]),":", dates[i]<dates[j])
