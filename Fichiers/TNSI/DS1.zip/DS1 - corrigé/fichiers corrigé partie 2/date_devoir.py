class Date :
    def __init__(self,j,m,a):
        self.jour = j
        self.mois = m
        self.annee = a

    def __str__(self):
        t = ["janvier","février","mars","avril","mai","juin","juillet","aout","septembre","octobre","novembre","décembre"]
        return str(self.jour)+" "+t[self.mois-1]+" "+str(self.annee)   

    def __lt__(self, d):
        a1 = self.annee
        m1 = self.mois
        j1 = self.jour
        a2 = d.annee
        m2 = d.mois
        j2 = d.jour
        if a1<a2:
            return True
        elif a1>a2:
            return False
        else:
            if m1<m2:
                return True
            elif m1>m2:
                return False
            else:
                return j1<j2

