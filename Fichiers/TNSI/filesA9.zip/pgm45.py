def rendu_monnaie(pieces, s):
    """renvoie le nombre minimal de pièces pour faire
       la somme s avec le système pieces"""
    if s == 0:
        return 0
    r = s   # s = 1 + 1 + ... + 1 dans le pire des cas
    for p in pieces:
        if p <= s:
            r = min(r, 1 + rendu_monnaie(pieces, s - p))
    return r
