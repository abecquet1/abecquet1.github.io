def rendu_monnaie(pieces, s):
    """renvoie le nombre minimal de pièces pour faire
       la somme s avec le système pieces"""
    nb = [0] * (s + 1)
    for n in range(1, s + 1):
        nb[n] = n # n = 1 + 1 + ... + 1 dans le pire des cas
        for p in pieces:
            if p <= n:
                nb[n] = min(nb[n], 1 + nb[n - p])
    return nb[s]
