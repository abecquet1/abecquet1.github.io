def rendu_monnaie_solution(pieces, s):
    """renvoie une liste minimale de pièces pour faire
       la somme s avec le système pieces"""
    nb = [0] * (s + 1)
    sol = [[]] * (s + 1)
    for n in range(1, s + 1):
        nb[n] = n
        sol[n] = [1] * n
        for p in pieces:
            if p <= n and 1 + nb[n - p] < nb[n]:
                nb[n] = 1 + nb[n - p]
                sol[n] = sol[n - p].copy()
                sol[n].append(p)
    return sol[s]
